package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeService {

	public Employee saveEmployee(Employee employee);

	public List<Employee> fetchEmployeeList();

	public Employee fetchEmployeeById(Long employeeId);

    public void deleteEmployeeById(Long employeeId);

	public Employee updateEmployee(Long employeeId, Employee employee);


	

}
